import * as utils from "./utils.js";
import * as classes from "./classes.js";

        let ctx,ctxTop,canvas,canvasTop;
        const canvasWidth = 1280, canvasHeight = 720;
        let target;
        var mousePos;
        let speed=1000;
        let targetCount = 30;
        let currentCount = 0;
        let crossHair;
		// #1 call the init function after the pages loads
		function init(){	
			canvas = document.getElementById('layer1');
            canvasTop = document.getElementById('layer2');
            canvas.width = canvasWidth;
            canvas.height = canvasHeight;
            canvasTop.width = canvasWidth;
            canvasTop.height = canvasHeight;
			ctx = canvas.getContext('2d');
            ctxTop = canvasTop.getContext('2d');
            crossHair = new classes.CrossHair();
            target= new classes.Target();
            
            setupUI();

            canvasTop.addEventListener('mousemove', function(evt) {
                mousePos = utils.getMousePos(canvas, evt);
                MakeCrosshair(crossHair);
                crossHair.move(mousePos.x,mousePos.y);  
                ctxTop.clearRect(0,0,1280,720);         
              }, false);
			ctx.fillStyle = 'black'; 
            ctx.fillRect(0,0,canvasWidth, canvasHeight);                    
            loop();

		};

        function setupUI(){
            // #6 - note the attribute selector we are using here
            let radioButtons = document.querySelectorAll("input[type=radio][name=speed]");
            for (let r of radioButtons){
                r.onchange = function(e){
                    // #7 - form values are returned as Strings, so we have to convert them to a Number
                        speed = Number(e.target.value) * 1000;                  
                        //console.log(speed);
                }
            }
        }
        
function loop(){

    
    drawText();
    drawTarget(target);
    setTimeout(function(){

        target.die(ctx);
        targetCount--;
        if(targetCount<0)
        return;

        requestAnimationFrame(loop)
    },speed);
    
}

function drawText(){
    
    ctx.font = "30px sans-serif";
    ctx.fillText("Targets Remaining: " + targetCount, 10, 50);
    ctx.fillText("Targets Shot: " + currentCount, 1000, 50);
}
        function MakeCrosshair(crosshair){

            ctxTop.beginPath();
            ctxTop.strokeStyle = "red";
            ctxTop.lineWidth=2;
            ctxTop.moveTo(crosshair.x,crosshair.y);
            // left line
            ctxTop.lineTo(crosshair.x-5,crosshair.y);
            // up line
            ctxTop.moveTo(crosshair.x,crosshair.y);
            ctxTop.lineTo(crosshair.x,crosshair.y-5);
             // down line
             ctxTop.moveTo(crosshair.x,crosshair.y);
             ctxTop.lineTo(crosshair.x,crosshair.y+5);
             // right line
             ctxTop.moveTo(crosshair.x,crosshair.y);      
             ctxTop.lineTo(crosshair.x+5,crosshair.y);
             ctxTop.closePath();
             ctxTop.stroke();                      
        }


        function drawTarget(incomingTarget){
            target.move();     
			ctx.fillStyle = incomingTarget.color;		
			ctx.fillRect(incomingTarget.x-incomingTarget.width/2,incomingTarget.y-incomingTarget.width/2,incomingTarget.width/2,incomingTarget.width/2);         
        }
		

        export {init};