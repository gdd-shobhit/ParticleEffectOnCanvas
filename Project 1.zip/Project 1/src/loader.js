import * as main from "./main.js";

window.onload = main.init;